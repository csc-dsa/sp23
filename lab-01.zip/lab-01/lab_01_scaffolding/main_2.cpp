#include "Cat.h"
#include "Dog.h"
#include "Bird.h"
#include "Hamster.h"
#include "Snake.h"
#include <string>
#include <fstream>
#include <sstream>

int main(int argc, char*argv[]){

    // Extract # of animals we're expecting to read from the CLA

    // Extract the name of the file we'll be reading from the CLA

	// Create a collection (data structure) of the appropriate size to hold the # of animals we are creating
	
	// Loop through the number of animals we have.
		
		// Read the current line from the file
		
		// Tokenize the line into type, hunger, thirst
		
		// Based on the type, create the appropriate animal and add it to your collection of animals
		
	// Loop through your collection of animals
	
		// Speak
		
		// Output hunger
		
		// Output thirst
}
